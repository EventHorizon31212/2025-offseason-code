## Visualizer 
https://visualizer.pedropathing.com/

## Making your own teleop code
Add a new class under the teleop package in org.firstinspires.ftc.teamcode.teleop

## Making your own autonomous code
Add a new class under the auto package in org.first.inspires.ftc.teamcode.pedroPathing.auto

## Gradle 
You might need to resync gradle because sometimes pedropathing doesn't import right away